import { useEffect, useState } from 'react';
import { supabase } from './supabase';

export default function App() {
  const [matches, setMatches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [customerName, setCustomerName] = useState('');
  const [seatCounts, setSeatCounts] = useState({});
  const [statusMessage, setStatusMessage] = useState('');
  const [bookingId, setBookingId] = useState(null);

  // Step 3: Fetch matches from Supabase
  const fetchMatches = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('matches')
      .select('*')
      .order('id', { ascending: true });

    if (error) {
      setStatusMessage(`Error loading matches: ${error.message}`);
    } else {
      setMatches(data || []);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchMatches();

    // Step 5: Realtime subscription to auto-update UI on DB changes
    const channel = supabase
      .channel('matches-realtime')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'matches' },
        (payload) => {
          if (payload.eventType === 'UPDATE') {
            setMatches((prev) =>
              prev.map((m) => (m.id === payload.new.id ? payload.new : m))
            );
          } else if (payload.eventType === 'INSERT') {
            setMatches((prev) => [...prev, payload.new]);
          } else if (payload.eventType === 'DELETE') {
            setMatches((prev) => prev.filter((m) => m.id !== payload.old.id));
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // Step 4: Insert booking and update available_seats
  const handleBookTicket = async (match) => {
    const seatsToBook = Number(seatCounts[match.id] || 1);

    if (!customerName.trim()) {
      setStatusMessage('Please enter your name before booking.');
      return;
    }
    if (seatsToBook < 1 || seatsToBook > match.available_seats) {
      setStatusMessage(`Please select between 1 and ${match.available_seats} seats.`);
      return;
    }

    setBookingId(match.id);
    setStatusMessage('');

    // 1. Insert into bookings table
    const { error: bookingError } = await supabase.from('bookings').insert([
      {
        match_id: match.id,
        customer_name: customerName.trim(),
        seats_booked: seatsToBook,
        total_price: seatsToBook * Number(match.ticket_price),
      },
    ]);

    if (bookingError) {
      setStatusMessage(`Booking failed: ${bookingError.message}`);
      setBookingId(null);
      return;
    }

    // 2. Update available_seats in matches table
    const { error: updateError } = await supabase
      .from('matches')
      .update({ available_seats: match.available_seats - seatsToBook })
      .eq('id', match.id);

    if (updateError) {
      setStatusMessage(`Seat update failed: ${updateError.message}`);
    } else {
      setStatusMessage(
        `Booked ${seatsToBook} seat(s) for ${match.team_a} vs ${match.team_b}!`
      );
    }

    setBookingId(null);
  };

  if (loading) return <p style={{ padding: 24 }}>Loading IPL matches...</p>;

  return (
    <div style={{ maxWidth: 720, margin: '0 auto', padding: 24, fontFamily: 'sans-serif' }}>
      <h1>IPL Ticket Booking</h1>

      <div style={{ marginBottom: 20 }}>
        <label>
          <strong>Your Name: </strong>
          <input
            type="text"
            value={customerName}
            onChange={(e) => setCustomerName(e.target.value)}
            placeholder="Enter your name"
            style={{ padding: 8, width: 240, marginLeft: 8 }}
          />
        </label>
      </div>

      {statusMessage && (
        <p style={{ padding: 10, background: '#f0f4ff', borderRadius: 6 }}>
          {statusMessage}
        </p>
      )}

      <div style={{ display: 'grid', gap: 16 }}>
        {matches.map((match) => (
          <div
            key={match.id}
            style={{
              border: '1px solid #ddd',
              borderRadius: 8,
              padding: 16,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
          >
            <div>
              <h3 style={{ margin: '0 0 6px' }}>
                {match.team_a} vs {match.team_b}
              </h3>
              <p style={{ margin: '0 0 4px', color: '#555' }}>{match.venue}</p>
              <p style={{ margin: 0 }}>
                Price: <strong>₹{match.ticket_price}</strong> | Available Seats:{' '}
                <strong>{match.available_seats}</strong>
              </p>
            </div>

            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <input
                type="number"
                min="1"
                max={match.available_seats}
                value={seatCounts[match.id] || 1}
                onChange={(e) =>
                  setSeatCounts({ ...seatCounts, [match.id]: e.target.value })
                }
                disabled={match.available_seats === 0}
                style={{ width: 60, padding: 6 }}
              />
              <button
                onClick={() => handleBookTicket(match)}
                disabled={match.available_seats === 0 || bookingId === match.id}
                style={{ padding: '8px 14px', cursor: 'pointer' }}
              >
                {match.available_seats === 0
                  ? 'Sold Out'
                  : bookingId === match.id
                  ? 'Booking...'
                  : 'Book'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}