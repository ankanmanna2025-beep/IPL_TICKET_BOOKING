
function Navbar() {
  return (
    <nav className="navbar">
      <h2>IPL TICKETS</h2>

      <ul>
        <li><a href="#home">Home</a></li>
        <li><a href="#matches">Matches</a></li>
        <li><a href="#about">About</a></li>
        <li><a href="#booking">Book Tickets</a></li>
      </ul>
    </nav>
  );
}

export default Navbar;
