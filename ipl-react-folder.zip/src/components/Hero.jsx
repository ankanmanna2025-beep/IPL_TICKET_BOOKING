
function Hero() {
  return (
    <section className="hero" id="home">
      <h1>Experience The Stadium Energy Live!</h1>

      <p>
        Book your IPL tickets and enjoy
        the excitement of live cricket.
      </p>

      <a href="#matches" className="hero-btn">
        View Matches
      </a>
    </section>
  );
}

export default Hero;
