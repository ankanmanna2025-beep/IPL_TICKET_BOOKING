
function MatchCard({ team1, team2, date, venue, price }) {
  return (
    <div className="match-card">
      <h3>{team1} VS {team2}</h3>

      <p><strong>Date:</strong> {date}</p>

      <p><strong>Venue:</strong> {venue}</p>

      <p><strong>Ticket Price:</strong> ₹{price}</p>

      <button onClick={() => alert("Match selected!")}>
        Book Ticket
      </button>
    </div>
  );
}

export default MatchCard;
