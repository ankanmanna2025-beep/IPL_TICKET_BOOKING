
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://lhyypulppvhsgfeiuwtv.supabase.co';

const supabasePublishableKey =
  'sb_publishable_1D1lkStLmy0FBX-7CVj1EQ_wNjcG3NE';

export const supabase = createClient(
  supabaseUrl,
  supabasePublishableKey
);
